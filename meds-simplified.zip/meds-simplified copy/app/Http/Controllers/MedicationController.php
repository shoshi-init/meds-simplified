<?php

namespace App\Http\Controllers;

use App\Models\Medication;
use Illuminate\Http\Request;

class MedicationController extends Controller
{
    // Display a list of medications
    public function index()
    {
        // Fetch medications for the authenticated user
        $medications = Medication::where('user_id', auth()->id())->get();

        // Pass medications to the view
        return view('medications.index', compact('medications'));
    }

    public function edit(Medication $medication)
    {
        return view('medications.edit', compact('medication'));
    }

    // Show the form to create a new medication
    public function create()
    {
        return view('medications.create');
    }

    public function update(Request $request, Medication $medication)
    {
        // Validate the incoming data
        $request->validate([
            'name' => 'required|string|max:255',
            'dosage' => 'required|string|max:255',
            'frequency' => 'required|string',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
        ]);

        // Update the medication record
        $medication->update([
            'name' => $request->name,
            'dosage' => $request->dosage,
            'frequency' => $request->frequency,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
        ]);

        // Redirect back to the medications list with a success message
        return redirect()->route('medications.index')->with('success', 'Medication updated successfully!');
    }

    // Store a new medication
    public function store(Request $request)
{
    // Validate the incoming data
    $request->validate([
        'name' => 'required|string|max:255',      // Validate medication name
        'dosage' => 'required|string|max:255',    // Validate dosage
        'frequency' => 'required|string',         // Validate frequency
        'start_date' => 'required|date',          // Validate start date
        'end_date' => 'required|date|after:start_date', // Validate end date, must be after start date
    ]);

    // If validation passes, create the medication
    Medication::create([
        'user_id' => auth()->id(),                // Assign user ID from authenticated user
        'name' => $request->name,                 // Get medication name from form input
        'dosage' => $request->dosage,             // Get dosage from form input
        'frequency' => $request->frequency,       // Get frequency from form input
        'start_date' => $request->start_date,     // Get start date from form input
        'end_date' => $request->end_date,         // Get end date from form input
    ]);

    // Redirect back with a success message
    return redirect()->route('medications.index')->with('success', 'Medication added successfully!');
}

public function destroy(Medication $medication)
{
    // Delete the medication record
    $medication->delete();

    // Redirect back to the medications list with a success message
    return redirect()->route('medications.index')->with('success', 'Medication deleted successfully!');
}


}

?>