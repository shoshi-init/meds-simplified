@extends('layouts.app')

@section('content')
    <div class="text-center mb-8">
        <h2 class="text-3xl font-semibold text-gray-800">Medications List</h2>
        <p class="text-gray-600 mt-2">Manage your medications and their schedules.</p>
    </div>

    <div class="flex justify-end mb-6">
        <a href="{{ route('medications.create') }}" class="bg-indigo-600 text-white py-2 px-6 rounded-md hover:bg-indigo-700 transition-colors">Add New Medication</a>
    </div>

    <div class="space-y-4">
        @foreach ($medications as $medication)
            <div class="bg-white shadow-md rounded-lg p-6 flex justify-between items-center">
                <div>
                    <h3 class="text-xl font-medium text-gray-800">{{ $medication->name }}</h3>
                    <p class="text-gray-600">Dosage: {{ $medication->dosage }} | Frequency: {{ $medication->frequency }}</p>
                </div>
                <div class="flex space-x-4">
                    <a href="{{ route('medications.edit', $medication) }}" class="text-indigo-600 hover:text-indigo-700 transition-colors">Edit</a>
                    <form action="{{ route('medications.destroy', $medication) }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="text-red-600 hover:text-red-700 transition-colors">Delete</button>
                    </form>
                </div>
            </div>
        @endforeach
    </div>
@endsection
