<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Health Reminder</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <!-- TailwindCSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

<!-- AlpineJS for interactivity -->
<script src="https://cdn.jsdelivr.net/npm/alpinejs@2.8.2/dist/alpine.min.js" defer></script>
    @vite('resources/css/app.css')
</head>
<body class="bg-gray-50 font-inter antialiased">

    <!-- Navbar -->
    <nav class="bg-white shadow-md py-4">
        <div class="max-w-7xl mx-auto px-6 flex justify-between items-center">
            <a href="/" class="text-2xl font-semibold text-gray-800 hover:text-indigo-600 transition-colors">Health Reminder</a>
            <div class="space-x-6">
                <a href="{{ route('medications.index') }}" class="text-gray-600 hover:text-indigo-600 transition-colors">Medications</a>
                <a href="{{ route('welcome') }}" class="text-gray-600 hover:text-indigo-600 transition-colors">Home</a>
                @auth
                    <a href="{{ route('logout') }}" class="text-gray-600 hover:text-indigo-600 transition-colors">Logout</a>
                @else
                    <a href="{{ route('login') }}" class="text-gray-600 hover:text-indigo-600 transition-colors">Login</a>
                    <a href="{{ route('register') }}" class="text-gray-600 hover:text-indigo-600 transition-colors">Register</a>
                @endauth
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="py-12">
        <div class="max-w-7xl mx-auto px-6">
            @yield('content')
        </div>
    </main>

    <!-- Footer (Optional) -->
    <footer class="bg-gray-200 py-6">
        <div class="text-center text-gray-600">
            <p>&copy; {{ date('Y') }} Health Reminder. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
